### Report files
Project Report.ipynb is the main report file.
BaghChal Game Overview.ipynb is explanation of the code and can be executed. This file is linked from "Project Report.ipynb".

### Executing the game agent
python3 agent.py

#### Dependencies
Numpy